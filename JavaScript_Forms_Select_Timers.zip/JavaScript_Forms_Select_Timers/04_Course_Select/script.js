const courses = {
  js: {info:"JavaScript — 72 часа", price:25000}, python:{info:"Python — 96 часов",price:30000},
  html:{info:"HTML и CSS — 48 часов",price:18000}, node:{info:"Node.js — 60 часов",price:22000}
};
const select = document.getElementById("course");
select.addEventListener("change", function() {
  const course = courses[this.value];
  document.getElementById("result").textContent = course ? `${course.info}. Стоимость: ${course.price.toLocaleString("ru-RU")} ₸.` : "Выберите курс";
  document.getElementById("enroll").disabled = !course;
  document.getElementById("message").textContent = "";
});
document.getElementById("enroll").addEventListener("click", () => {
  if (courses[select.value]) document.getElementById("message").textContent = `Вы записаны на курс: ${select.options[select.selectedIndex].text}.`;
});