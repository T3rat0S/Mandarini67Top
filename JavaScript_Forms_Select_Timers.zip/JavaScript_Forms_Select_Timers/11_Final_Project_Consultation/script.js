const teachers = [
 {id:"a",name:"Александр Иванов",slots:["Понедельник, 10:00","Понедельник, 11:00","Среда, 14:00"]},
 {id:"b",name:"Мария Петрова",slots:["Вторник, 09:00","Вторник, 12:00","Четверг, 15:00"]},
 {id:"c",name:"Данияр Садыков",slots:["Среда, 10:00","Пятница, 13:00","Пятница, 15:00"]}
];
let timer=null,secondsLeft=120,currentBooking=null,bookings=[];
const teacherSelect=document.getElementById("teacher"),slotSelect=document.getElementById("slot");
function loadTeachers(){teachers.forEach(t=>teacherSelect.add(new Option(t.name,t.id)));}
function loadTimeSlots(){const teacher=teachers.find(t=>t.id===teacherSelect.value);slotSelect.innerHTML='<option value="">Выберите время</option>';if(!teacher){slotSelect.disabled=true;return;}teacher.slots.forEach(s=>slotSelect.add(new Option(s,s)));slotSelect.disabled=false;}
function validateForm(){const name=document.getElementById("studentName").value.trim(),email=document.getElementById("email").value.trim(),group=document.getElementById("studentGroup").value.trim();return name.length>=3&&email.includes("@")&&group.length>0&&teacherSelect.value!==""&&slotSelect.value!=="";}
function checkAvailability(){return !bookings.some(b=>b.teacherId===teacherSelect.value&&b.slot===slotSelect.value&&b.status==="Подтверждена");}
function createBooking(){const teacher=teachers.find(t=>t.id===teacherSelect.value);currentBooking={id:Date.now(),name:document.getElementById("studentName").value.trim(),email:document.getElementById("email").value.trim(),group:document.getElementById("studentGroup").value.trim(),teacherId:teacher.id,teacher:teacher.name,slot:slotSelect.value,status:"Ожидает подтверждения"};bookings.push(currentBooking);document.getElementById("bookingInfo").textContent=`${currentBooking.name}, ${currentBooking.group}. Преподаватель: ${currentBooking.teacher}. Время: ${currentBooking.slot}.`;document.getElementById("confirmation").hidden=false;secondsLeft=120;startConfirmationTimer();showBookings();}
function startConfirmationTimer(){clearInterval(timer);updateTimer();timer=setInterval(()=>{secondsLeft--;updateTimer();if(secondsLeft<=0){clearInterval(timer);timer=null;if(currentBooking&&currentBooking.status==="Ожидает подтверждения"){currentBooking.status="Время подтверждения истекло";document.getElementById("status").textContent="Время подтверждения истекло. Создайте заявку заново.";showBookings();document.getElementById("confirmation").hidden=true;}}},1000);}
function updateTimer(){document.getElementById("confirmTimer").textContent=`${String(Math.floor(secondsLeft/60)).padStart(2,"0")}:${String(secondsLeft%60).padStart(2,"0")}`;}
function cancelBooking(){if(timer!==null){clearInterval(timer);timer=null;}if(currentBooking){currentBooking.status="Отменена";showBookings();}document.getElementById("confirmation").hidden=true;document.getElementById("status").textContent="Запись отменена.";}
function showBookings(){const box=document.getElementById("bookings");if(!bookings.length){box.innerHTML='<p class="muted">Пока заявок нет.</p>';return;}box.innerHTML=bookings.map(b=>`<article class="product"><b>${b.name}</b><span>${b.teacher} — ${b.slot}</span><span>Группа: ${b.group}</span><strong>${b.status}</strong></article>`).join("");}
teacherSelect.addEventListener("change",loadTimeSlots);
document.getElementById("bookingForm").addEventListener("submit",event=>{event.preventDefault();if(!validateForm()){document.getElementById("status").textContent="Заполните все поля корректно.";return;}if(!checkAvailability()){document.getElementById("status").textContent="Этот временной интервал уже занят. Выберите другой.";return;}document.getElementById("status").textContent="";createBooking();});
document.getElementById("cancel").addEventListener("click",cancelBooking);
loadTeachers();showBookings();