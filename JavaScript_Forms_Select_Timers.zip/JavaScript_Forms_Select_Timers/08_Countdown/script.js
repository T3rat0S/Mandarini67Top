let remaining=10, timer=null;
const display=document.getElementById("time"), message=document.getElementById("message"), duration=document.getElementById("duration");
function render(){display.textContent=`${String(Math.floor(remaining/60)).padStart(2,"0")}:${String(remaining%60).padStart(2,"0")}`;}
function startCountdown(){if(timer!==null||remaining<=0)return;message.textContent="";timer=setInterval(()=>{remaining--;render();if(remaining<=0){pauseCountdown();message.textContent="Время вышло!";}},1000);}
function pauseCountdown(){clearInterval(timer);timer=null;}
function resetCountdown(){pauseCountdown();remaining=Number(duration.value);message.textContent="";render();}
duration.addEventListener("change",resetCountdown);
document.getElementById("start").addEventListener("click",startCountdown);
document.getElementById("pause").addEventListener("click",pauseCountdown);
document.getElementById("reset").addEventListener("click",resetCountdown);render();