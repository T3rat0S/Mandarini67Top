const data = {
 software: {"РПО-24-2":["Алексей Иванов","Мария Петрова"],"РПО-25-2":["Кирилл Смирнов","Данил Ким"]},
 design: {"ДИЗ-24-1":["Анна Соколова","Елена Орлова"],"ДИЗ-25-1":["Илья Волков","Полина Белова"]}
};
const specialty = document.getElementById("specialty"), group = document.getElementById("group"), student = document.getElementById("student");
function fill(select, values, placeholder) { select.innerHTML = `<option value="">${placeholder}</option>`; values.forEach(v => select.add(new Option(v,v))); select.disabled = values.length === 0; }
specialty.addEventListener("change", () => {
  fill(group, Object.keys(data[specialty.value] || {}), "Выберите группу"); fill(student, [], "Сначала выберите группу"); show();
});
group.addEventListener("change", () => { fill(student, data[specialty.value]?.[group.value] || [], "Выберите студента"); show(); });
student.addEventListener("change", show);
function show() {
 const s = specialty.options[specialty.selectedIndex]?.text || "";
 document.getElementById("result").textContent = group.value && student.value ? `Специальность: ${s}. Группа: ${group.value}. Студент: ${student.value}.` : "";
}