const slides=[
 {src:"https://picsum.photos/id/1015/800/420",title:"Горный пейзаж"},
 {src:"https://picsum.photos/id/1011/800/420",title:"Лес и озеро"},
 {src:"https://picsum.photos/id/1016/800/420",title:"Скалистые горы"},
 {src:"https://picsum.photos/id/1020/800/420",title:"Природа"},
 {src:"https://picsum.photos/id/1039/800/420",title:"Побережье"}
];
let current=0, timer=null, playing=true;
function showSlide(index){current=(index+slides.length)%slides.length;document.getElementById("slideImage").src=slides[current].src;document.getElementById("caption").textContent=slides[current].title;document.getElementById("indicator").textContent=`Слайд ${current+1} из ${slides.length}`;}
function nextSlide(){showSlide(current+1);}
function prevSlide(){showSlide(current-1);}
function startAuto(){if(timer!==null)return;timer=setInterval(nextSlide,3000);playing=true;document.getElementById("toggle").textContent="Остановить автопрокрутку";}
function stopAuto(){clearInterval(timer);timer=null;playing=false;document.getElementById("toggle").textContent="Запустить автопрокрутку";}
document.getElementById("next").addEventListener("click",nextSlide);document.getElementById("prev").addEventListener("click",prevSlide);
document.getElementById("toggle").addEventListener("click",()=>playing?stopAuto():startAuto());
showSlide(0);startAuto();