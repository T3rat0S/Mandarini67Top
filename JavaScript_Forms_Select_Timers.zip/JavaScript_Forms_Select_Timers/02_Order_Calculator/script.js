function calculateTotal(price, quantity) { return price * quantity; }
document.getElementById("orderForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const price = Number(document.getElementById("price").value);
  const quantity = Number(document.getElementById("quantity").value);
  const result = document.getElementById("result");
  if (!Number.isFinite(price) || !Number.isInteger(quantity) || price < 0 || quantity <= 0) {
    result.textContent = "Введите корректные неотрицательную цену и положительное целое количество."; return;
  }
  const subtotal = calculateTotal(price, quantity);
  const discount = subtotal >= 50000 ? subtotal * 0.10 : 0;
  result.textContent = `Сумма: ${subtotal.toLocaleString("ru-RU")} ₸. Скидка: ${discount.toLocaleString("ru-RU")} ₸. Итого: ${(subtotal-discount).toLocaleString("ru-RU")} ₸.`;
});