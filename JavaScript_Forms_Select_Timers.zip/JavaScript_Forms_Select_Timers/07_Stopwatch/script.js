let seconds=0, timer=null;
function formatTime(value){const m=Math.floor(value/60),s=value%60;return `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;}
function update(){document.getElementById("time").textContent=formatTime(seconds);}
function startTimer(){if(timer!==null)return;timer=setInterval(()=>{seconds++;update();},1000);}
function stopTimer(){clearInterval(timer);timer=null;}
function resetTimer(){stopTimer();seconds=0;update();}
document.getElementById("start").addEventListener("click",startTimer);
document.getElementById("stop").addEventListener("click",stopTimer);
document.getElementById("reset").addEventListener("click",resetTimer); update();