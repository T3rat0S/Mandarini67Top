const products = [
 ["Ноутбук Lenovo IdeaPad","Ноутбуки",280000],["Ноутбук ASUS VivoBook","Ноутбуки",310000],["Ноутбук Acer Aspire","Ноутбуки",245000],["MacBook Air","Ноутбуки",520000],["Ноутбук HP 250","Ноутбуки",210000],
 ["iPhone 13","Телефоны",230000],["Samsung Galaxy A55","Телефоны",190000],["Xiaomi Redmi Note","Телефоны",115000],["iPhone 15","Телефоны",360000],["Samsung Galaxy S24","Телефоны",420000],
 ["iPad 10","Планшеты",210000],["Samsung Tab A9","Планшеты",95000],["Xiaomi Pad 6","Планшеты",175000],["iPad Air","Планшеты",390000],["Lenovo Tab M10","Планшеты",85000]
].map(([name,category,price])=>({name,category,price}));
function render() {
 let list = products.filter(p => document.getElementById("category").value === "all" || p.category === document.getElementById("category").value);
 const r = document.getElementById("range").value;
 if(r==="low") list=list.filter(p=>p.price<100000); if(r==="mid") list=list.filter(p=>p.price>=100000&&p.price<=300000); if(r==="high") list=list.filter(p=>p.price>300000);
 list.sort((a,b)=>document.getElementById("sort").value==="asc"?a.price-b.price:b.price-a.price);
 document.getElementById("products").innerHTML = list.length ? list.map(p=>`<article class="product"><b>${p.name}</b><span>${p.category}</span><strong>${p.price.toLocaleString("ru-RU")} ₸</strong></article>`).join("") : "<p>Товары не найдены.</p>";
}
["category","range","sort"].forEach(id=>document.getElementById(id).addEventListener("change",render)); render();