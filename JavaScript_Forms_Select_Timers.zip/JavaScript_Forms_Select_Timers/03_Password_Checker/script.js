const password = document.getElementById("password");
document.getElementById("toggle").addEventListener("click", () => {
  const hidden = password.type === "password"; password.type = hidden ? "text" : "password";
  document.getElementById("toggle").textContent = hidden ? "Скрыть пароль" : "Показать пароль";
});
password.addEventListener("input", () => {
  const value = password.value;
  const checks = [value.length >= 8, /[A-Za-zА-Яа-я]/.test(value) && /\d/.test(value), /[^A-Za-zА-Яа-я0-9]/.test(value)];
  document.querySelectorAll("#checks li").forEach((li, i) => li.classList.toggle("ok", checks[i]));
  const score = checks.filter(Boolean).length;
  document.getElementById("strength").textContent = !value ? "Введите пароль" : ["Слабый пароль", "Средний пароль", "Хороший пароль", "Надёжный пароль"][score];
  document.getElementById("strengthBar").style.width = (score/3*100) + "%";
});