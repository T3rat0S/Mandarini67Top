document.getElementById("studentForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const age = Number(document.getElementById("age").value);
  const group = document.getElementById("group").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const phonePattern = /^\+?[0-9\s()-]{10,20}$/;
  const result = document.getElementById("result");
  if (!name || !email || age < 14 || age > 100 || !group || !phonePattern.test(phone)) {
    result.textContent = "Проверьте данные. Телефон должен содержать от 10 до 20 цифр и допустимые символы.";
    result.className = "error"; return;
  }
  result.textContent = `Студент ${name} зарегистрирован! Группа: ${group}. Возраст: ${age}. Email: ${email}. Телефон: ${phone}.`;
  result.className = "success";
});